<template>
  <div>
    <h1>head nav</h1>
  </div>
</template>

<script>
export default {
  name: 'headNav'
}
</script>

<style scoped>

</style>
