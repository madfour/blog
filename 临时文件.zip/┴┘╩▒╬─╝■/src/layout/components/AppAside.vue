<template>
    <div class="aside-container">
    app-aside
    </div>
</template>

<script>
export default {
  name: '',
  data () {
    return {}
  },
  methods: {}
}
</script>

<style lang="less" scoped>
  @import "~@/styles/variable";
  .aside-container{
    flex: 0 0 @asideWith;
    background-color: #f1f1f1;
    color: @asideColor;
  }

</style>
