<template>
    <div class="layout-main">app-main</div>
</template>

<script>
export default {
  name: 'AppMain'
}
</script>

<style scoped>

</style>
