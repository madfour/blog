<template>
    <div>
      <h1>basicHead</h1>
    </div>
</template>

<script>
export default {
  name: 'basicHead'
};
</script>

<style scoped>

</style>
