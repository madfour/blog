export { default as sidebar } from './sidebar';
export { default as basicHead } from './basicHead';
export { default as basicMain } from './basicMain';
