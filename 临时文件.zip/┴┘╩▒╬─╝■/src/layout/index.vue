<template>
  <div class="app-layout">
    <AppAside/>
    <div class="main-container">
      <HeadNav class="main-head" />
      <AppMain class="app-main"/>
    </div>
  </div>
</template>

<script>
import { AppAside, AppMain, HeadNav } from './components'

export default {
  name: '',
  components: {
    AppAside,
    AppMain,
    HeadNav
  },
  data () {
    return {}
  },
  methods: {}
}
</script>

<style scoped lang="less">
  @import "../styles/common";
  @import "../styles/variable";

  .app-layout {
    width: 100%;
    height: 100%;
    display: flex;
    overflow: hidden;
  }

  .main-container {
    overflow: hidden;
    flex: 1 1 0%;
  }

</style>
